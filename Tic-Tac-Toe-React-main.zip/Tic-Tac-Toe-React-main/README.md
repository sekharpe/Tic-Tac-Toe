# Tic Tac Toe Game

This is a Simple Tic Tac Toe Game playable for 2 players.

## Installation

This requires [React](https://reactjs.org/) v18.2.0+ to run.

Install the dependencies and start the server.

```sh
npm run start
```

[![](https://markdown-videos.deta.dev/youtube/OmBbyFmM4yY)](https://youtu.be/OmBbyFmM4yY)

https://youtu.be/OmBbyFmM4yY

**Enjoy The Game!**
